package com.psj.datajpa.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.psj.datajpa.entity.Employee;

@Repository
public interface EmpRepository extends CrudRepository<Employee, Serializable> {
	
}
