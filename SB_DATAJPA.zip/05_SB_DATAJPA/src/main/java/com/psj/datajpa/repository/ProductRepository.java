package com.psj.datajpa.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.psj.datajpa.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Serializable> {

}
