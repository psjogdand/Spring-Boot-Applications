package com.psj.datajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.psj.datajpa.entity.Employee;
import com.psj.datajpa.entity.Product;
import com.psj.datajpa.repository.EmpRepository;
import com.psj.datajpa.repository.ProductRepository;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctxt = SpringApplication.run(Application.class, args);
		
		EmpRepository bean = ctxt.getBean(EmpRepository.class);
		
		Employee emp = new Employee();
		emp.setEmpId(3);
		emp.setEmpName("Harsh");
		emp.setEmpSal(300000);
		bean.save(emp);
		//bean.deleteById(2);
		System.out.println("++++emp++++"+emp.getEmpId());
		
		ProductRepository productRepository = ctxt.getBean(ProductRepository.class);
		Product product = new Product();
		product.setProduct_id(201);
		product.setProduct_name("Mouse");
		product.setPrice(1000.00);
		productRepository.save(product);
		
		
		System.out.println("++++++++++++Record Saved!++++++++++++++");
		ctxt.close();
	}

}
